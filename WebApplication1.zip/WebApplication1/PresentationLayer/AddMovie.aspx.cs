﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using WebApplication1.BusinessLayer;

namespace WebApplication1.PresentationLayer
{
    public partial class AddMovie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
  
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (imgUpload.PostedFile != null)
            {
                string name = "Minesweeper";
                int year = 2022;
                float rating = 7.1F;
                string duration = "01:45:05";
                float price = 2.5F;
                string imagename = Path.GetFileName(imgUpload.PostedFile.FileName);
                //string imagepath = Server.MapPath(@"..\Posters\" + imagename);
                string imagepath = Server.MapPath(@"../Posters/" + imagename);
                string description = "A bomb disposing squad was challenged to find and dispose all the mines in a garden. The Sqaud tried to save as many people as they can by sweeping all the mines.";
                imgUpload.SaveAs(imagepath);
                Movie movie = new Movie(name, year, rating, duration, price, imagename, description);
                movie.AddToDb();
            }
        }
    }
}