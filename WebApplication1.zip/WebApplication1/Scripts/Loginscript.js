﻿function login() {
    var nameBox = document.getElementById('namebox')
    var emailBox = document.getElementById('emailbox')
    var passwordBox = document.getElementById('passwordbox')

    var namevalue, emailvalue, passwordvalue
    namevalue = nameBox.value
    emailvalue = emailBox.value
    passwordvalue = passwordBox.value

    if (validate(namevalue, emailvalue, passwordvalue)) {
        validateOnServerSide(namevalue, emailvalue, passwordvalue)
    }
}
function validateOnServerSide(namevalue, emailvalue, passwordvalue) {
    $.ajax({
        type: "POST",
        url: "Login.aspx/Loginuser?paramater=parameter",
        data: "{ name: '" + namevalue + "',email: '" + emailvalue + "',password: '" + passwordvalue + "'}",

        contentType: "application/json; charset=utf-8",

        dataType: "json",

        async: "false",

        cache: "false",

        success: function (result) {
            var message
            switch (result.d) {
                case "invalidN":
                    message = "Incorrect Username"
                    break;
                case "invalidE":
                    message = "Incorrect Email"
                    break;
                case "invalidP":
                    message = "Incorrect Password"
                    break;
                case "success":
                    message = "Login successfully"
                    break;
            }
            alert(message);
            //if (result.d=="success")
            //{
            //    setTimeout(window.location.href = "Login.aspx",200)
            //}
        }
    });
}
function validate(namevalue, emailvalue, passwordvalue) {

    if (namevalue == "") {
        alert("Please enter a user name")
        return false;
    }
    else if (emailvalue == "") {
        alert("Please enter an email")
        return false;
    }
    else if (passwordvalue == "") {
        alert("Please enter a password")
        return false;
    }

    return true;
}