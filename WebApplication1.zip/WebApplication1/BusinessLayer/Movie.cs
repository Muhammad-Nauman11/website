﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;

namespace WebApplication1.BusinessLayer
{
    public class Movie
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =MovieStore;User ID=curemd; Password=abc");
        int ID { get; set; }
        string Name { get; set; }
        int Year { get; set; }
        float Rating { get; set; }
        string Duration { get; set; }
        float Price { get; set; }
        string ImgPath { get; set; }
        string Description { get; set; }

        public Movie() 
        {
            
        }
        public Movie(string name, int year, float rating, string duration, float price, string imgpath, string description )
        {
            Name = name;
            Year = year;
            Rating = rating;
            Duration = duration;
            Price = price;
            ImgPath = imgpath;
            Description = description;
        }
        public string AddToDb() 
        {
            SqlCommand com = new SqlCommand("addMovie", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@MovieName", Name);
            com.Parameters.AddWithValue("@Year", Year);
            com.Parameters.AddWithValue("@Rating", Rating);
            com.Parameters.AddWithValue("@Duration", Duration);
            com.Parameters.AddWithValue("@Price", Price);
            com.Parameters.AddWithValue("@Image_Path", ImgPath);
            com.Parameters.AddWithValue("@Description", Description);


            con.Open();
          
            int progress=com.ExecuteNonQuery();
            con.Close();
            if (progress != -1) 
            {
                return "Unable to add move";
            }
            return "Movie is added successfully";
        }
        public DataTable getAllMovies()
        {
            DataTable t1 = new DataTable();
            using (con)
            {
                con.Open();
                SqlCommand com = new SqlCommand("getAllMovies", con);
                com.CommandType = CommandType.StoredProcedure;
                //SqlDataReader rdr = com.ExecuteReader();

                using (SqlDataAdapter a = new SqlDataAdapter(com))
                {
                    a.Fill(t1);
                }

            }
            return t1;
        }
        public void DeleteFromDB()
        {

        }
    }
}